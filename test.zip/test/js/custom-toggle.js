$(document).ready(function(){
 $('.viewTrigger').click(function(){
        
        var currentBox = $(this).closest('.schoolInfo-blocks').find('.triggerBox');
       
         currentBox.slideToggle();

        if ( $(this).find('i').hasClass("fa-ellipsis-h") ) {
             $(this).find('i').removeClass("fa-ellipsis-h");
             $(this).find('i').addClass("fa-caret-down");

            }else{
                 $(this).find('i').removeClass("fa-caret-down");
                $(this).find('i').addClass("fa-ellipsis-h");
            };
      });
});